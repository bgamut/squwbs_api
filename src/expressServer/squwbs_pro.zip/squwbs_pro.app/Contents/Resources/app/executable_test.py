import sys
path = sys.argv[1]+'/demofile.txt'
f = open(path,'a')
f.write("now the file has more content!")
f.close()
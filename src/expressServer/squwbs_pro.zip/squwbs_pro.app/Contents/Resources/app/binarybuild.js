var squwbs = require("./build/Release/squwbs.node")
var json = require("./soundSettings.json")
var fs = require('fs')
var stdin = process.argv.slice(2);
// if(stdin[2]){
//     squwbs.setSR(Number(stdin[2]))
//     console.log('sr set!')
// }
//console.log(typeof(stdin[0]))

//var left = stdin[0].replace('[','').replace(']','').split(',')
//var right = stdin[1].replace('[','').replace(']','').split(',')
squwbs.setSR(json.sr)
var left = json.left
var right = json.right
// for (var i = 0; i <left.length; i++){
//     left[i]=Number(left[i])
//     right[i]=Number(right[i])
// }
squwbs.process(0,0)
for(var i = 0; i <left.length; i++ ){
    left[i]= squwbs.process(left[i],right[i]).left
    right[i]=squwbs.process(left[i],right[i]).right
}
var output = {
    sr:44100,
    left:left,
    right:right
}
fs.writeFileSync('newSound.json',output)
console.log(left)
//squwbs.process(Number(stdin[0]),Number(stdin[1])))
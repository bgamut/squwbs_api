var exec = require('child_process').exec, child;
const child_process=require('child_process')
var fs = require('fs');
var path = require('path')
var programPath=''
var wav = require('node-wav')
var isWav = require('is-wav');
//var squwbs = require('./squwbs')
const {shell} = require('electron')
const electron = require('electron')

var fileIsLoaded=false
var p5=require('p5')
var readMode=false
var left=[]
var right=[]
var mono=[]
var side=[]
var obj={}
var deviationShow=false
var binSize=2**8
var globalArray=new Array(100).fill(0)
var globalLeft = new Array(binSize).fill(0)
var globalRight= new Array(binSize).fill(0)

var globalMono= new Array(binSize).fill(0)
var globalSide= new Array(binSize).fill(0)

var leftFFT=new Array(binSize).fill([0,0])
var rightFFT=new Array(binSize).fill([0,0])

var monoFFTList=[]
var sideFFTList=[]
var monoFFT=new Array(binSize).fill([0,0])
var sideFFT=new Array(binSize).fill([0,0])

var monoFFTAverage=new Array(binSize/2).fill(0)
var sideFFTAverage=new Array(binSize/2).fill(0)

var monoFFTDeviation=new Array(binSize/2).fill(0)
var sideFFTDeviation=new Array(binSize/2).fill(0)

var sample = 0;
var leftMagnitude=new Array(binSize).fill(0);
var rightMagnitude=new Array(binSize).fill(0);
var monoMagnitude=new Array(binSize/2).fill(0);
var sideMagnitude=new Array(binSize/2).fill(0);
var monoMagnitudeList=[]
var sideMagnitudeList=[]

const fft = require('fft-js').fft
const ifft = require('fft-js').ifft
const fftUtil = require('fft-js').util
const fftInPlace = require('fft-js').fftInPlace

function move(oldPath, newPath, callback) {

  //fs.rename(oldPath, newPath, function (err) {
  fs.copyFile(oldPath, newPath, function (err) {
      if (err) {
          if (err.code === 'EXDEV') {
              copy();
          } else {
              callback(err);
          }
          return;
      }
      callback();
  });

  function copy() {
      var readStream = fs.createReadStream(oldPath);
      var writeStream = fs.createWriteStream(newPath);

      readStream.on('error', callback);
      writeStream.on('error', callback);

      readStream.on('close', function () {
          //fs.unlink(oldPath, callback);
          console.log('copied')
      });

      readStream.pipe(writeStream);
  }
}


document.getElementById('party').addEventListener('click', function() {
    document.getElementById('business').click()
})


document.getElementById('business').onchange = function(e){

    console.log('business fired')
    

    var files = e.target.files; // FileList object

    //for (var i = 0, f; f = files[i]; i++) {
    const mainFunction=function(files,i){
      const desktopPath = (electron.app || electron.remote.app).getPath('desktop');
      var filepath = files[i].path
      var buffer = fs.readFileSync(filepath)
      console.log(filepath)
      if(isWav(buffer)==true){
        var result = wav.decode(buffer)
        var left= result.channelData[0].slice()
        var right = result.channelData[1].slice()
        var obj = {
          left:left,
          right:right,
          sampleRate:result.sampleRate,
          length:left.length
        }
        //var fullPathDirectory=path.join(path.dirname(filepath),'mastered_files')
        var fullPathDirectory=path.join(desktopPath,'mastered_files')
        var resourceBinary=path.join(__dirname,'squwbs_console/Builds/MacOSX/build/Debug','squwbs_console')
        var binaryPath = path.join(fullPathDirectory,'squwbs_console')
        // var binaryPath = path.join(fullPathDirectory,'.squwbs_console')
        console.log(resourceBinary)
        console.log(binaryPath)
        if (!fs.existsSync(fullPathDirectory)){
          fs.mkdirSync(fullPathDirectory);
        }
        move(resourceBinary,binaryPath,function(){
          var fullPathName=path.join(fullPathDirectory,'songInfo.json')
          var outFilePath = path.join(fullPathDirectory,'newSongInfo.json')
          // var fullPathName=path.join(fullPathDirectory,'.songInfoJson')
          // var outFilePath = path.join(fullPathDirectory,'.newSongInfoJson')
          fs.writeFileSync(fullPathName,JSON.stringify(obj))
          const command = binaryPath.replace(/(\s+)/g, '\\$1') + ' '+fullPathName.replace(/(\s+)/g, '\\$1')+' '+outFilePath.replace(/(\s+)/g, '\\$1')
          console.log(command)
          child_process.execSync(command)
          var info = fs.readFileSync(outFilePath,'utf8')
          var songJson = JSON.parse(info)

          console.log(songJson)
          var encoded=wav.encode([songJson.left,songJson.right],{sampleRate:songJson.sampleRate, float:true, bitDepth:16}).slice()
          var wavPath=path.join(fullPathDirectory,path.basename(filepath))
          fs.writeFileSync(wavPath,encoded)
          if(i<files.length-1){
            mainFunction(files,i+1)
            document.getElementById('text').innerHTML= Math.floor((i/(files.length-1))*10000)/100+'%'
            document.getElementById('bar').style.width = Math.floor((i/(files.length-1))*100)+'%';
          }
          else if(i>=files.length-1){
            fs.unlinkSync(fullPathName)
            fs.unlinkSync(outFilePath)
            fs.unlinkSync(binaryPath)
            //document.getElementById('text').innerHTML= fullPathDirectory.replace(/(\s+)/g, '\\$1')
            //document.getElementById('text').innerHTML="Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.";
            document.getElementById('text').innerHTML="Ready"
            //document.getElementById('text').href="file:///"+fullPathDirectory.replace(/(\s+)/g, '%20')
            document.getElementById('bar').style.width = '100%';
            document.getElementById('bar').style.backgroundColor='rgb(255,179,78)'
          }
        })
        
      }
      else{
        mainFunction(files,i+1)
      }
    }
    // }
    //console.log('iterated through files')
    mainFunction(files,0)
    //fileIsLoaded=true
    //window.requestAnimationFrame(animationFrameRequestCallBack)
  
}

function centerCanvas() {
    var x = (window.innerWidth - binSize) / 2;
    var y = (window.innerHeight - 100) / 2;
    cnv.position(x, y);
}






    // function setup(){
    //     cnv = createCanvas(binSize,100)
    //     //cnv = createCanvas(250,100)
    //     cnv.parent('sketch-holder')
    //     //background(255,0,200)
    //     background(255, 145, 166)
    //     // input = createFileInput(handleFile)
    //     // input.position(0,0)
    //     // input.id('business')
    //     // input.style('display','none')
    // }
    
    // // function handleFile(file){
    // //     console.log(file.file.path)
    // // }
    
    // function draw(){
    //     //clear()
    //     var binSize = 100
    //     var width=binSize
    //     //var width=250
    //     var height=100
    //     //background(180, 167, 248)
    //     background(255, 145, 166)
    //     noStroke()
    //     //fill(255, 145, 166)
    //     fill('white')
    //     //nostroke()
    //     var max=0
    //     for (var i =0; i<width; i++){
    //         //console.log(sample)
    //         // var barWidth = Math.ceil((width)/globalArray.length)
    //         // var barHeight= Math.floor((globalArray[i])*(height/2))
    //         // var barCoordX = Math.ceil(i*barWidth)
    //         // var barCoordY = 50+Math.floor(height/2*globalArray[i])
            
    //         //console.log(globalArray[i])

    //         fill('white')
    //         // var barWidth = Math.ceil((width)/monoFFT.length)
    //         // var barHeight= Math.floor(Math.abs(monoFFT[i][0])*(height))
    //         // var barCoordX = Math.ceil(i*barWidth)
    //         // var barCoordY = height-Math.floor(height*Math.abs(monoFFT[i][0]))
            
    //         // var barWidth = Math.ceil((width)/monoFFT.length)
    //         // var barHeight= Math.floor(monoFFT[i][0]*(height/2))
    //         // var barCoordX = Math.ceil(i*barWidth)
    //         // var barCoordY = height/2-Math.floor(height/2*monoFFT[i][0])

    //         // var barWidth = Math.ceil((width)/monoMagnitude.length)
    //         // var barHeight= Math.ceil((monoMagnitude[i])*(height))
    //         // var barCoordX = Math.ceil(i*barWidth)
    //         // var barCoordY = height-(Math.ceil(height/2*Math.log10(monoMagnitude[i]*10))+1)

    //         var barWidth = Math.ceil((width)/monoFFTAverage.length)
    //         var barHeight= Math.ceil((monoFFTAverage[i])*(height))
    //         var barCoordX = Math.ceil(i*barWidth)
    //         var barCoordY = height-(Math.ceil(height/2*Math.log10(monoFFTAverage[i]*10))+1)
    //         rect(barCoordX,barCoordY,barWidth,barHeight)
    //         fill(180, 167, 248)
    //         // barWidth = Math.ceil((width)/sideMagnitude.length)
    //         // barHeight= Math.ceil((sideMagnitude[i])*(height))            
    //         // barCoordX = Math.ceil(i*barWidth)
    //         // barCoordY = height-(Math.ceil(height/2*Math.log10(sideMagnitude[i]*10))+1)

    //         // barWidth = Math.ceil((width)/sideFFT.length)
    //         // barHeight= Math.floor(Math.abs(sideFFT[i][0])*(height))
    //         // barCoordX = Math.ceil(i*barWidth)
    //         // barCoordY = height-Math.floor(height*Math.abs(sideFFT[i]))

    //         // barWidth = Math.ceil((width)/sideFFT.length)
    //         // barHeight= Math.floor(sideFFT[i][0]*(height/2))
    //         // barCoordX = Math.ceil(i*barWidth)
    //         // barCoordY = height/2-Math.floor(height/2*sideFFT[i])

    //         barWidth = Math.ceil((width)/sideFFTAverage.length)
    //         barHeight= Math.ceil((sideFFTAverage[i])*(height))            
    //         barCoordX = Math.ceil(i*barWidth)
    //         barCoordY = height-(Math.ceil(height/2*Math.log10(sideFFTAverage[i]*10))+1)
    //         rect(barCoordX,barCoordY,barWidth,barHeight)
    //         if(deviationShow==true){
    //           fill(180, 167, 248)
    //           barWidth = Math.ceil((width)/monoFFTDeviation.length)
    //           barHeight= 1           
    //           barCoordX = Math.ceil(i*barWidth)
    //           barCoordY = height-(Math.ceil(height/2*Math.log10(monoFFTAverage[i]*10))+1)-(Math.ceil(height/2*Math.log10(monoFFTDeviation[i]*10))+1)
    //           rect(barCoordX,barCoordY,barWidth,barHeight)
    //           fill(255, 145, 166)
    //           barWidth = Math.ceil((width)/sideFFTDeviation.length)
    //           barHeight= 1           
    //           barCoordX = Math.ceil(i*barWidth)
    //           barCoordY = height-(Math.ceil(height/2*Math.log10(sideFFTAverage[i]*10))+1)-(Math.ceil(height/2*Math.log10(sideFFTDeviation[i]*10))+1)
    //           rect(barCoordX,barCoordY,barWidth,barHeight)

    //           fill(180, 167, 248)
    //           barWidth = Math.ceil((width)/monoFFTDeviation.length)
    //           barHeight= 1           
    //           barCoordX = Math.ceil(i*barWidth)
    //           barCoordY = height-(Math.ceil(height/2*Math.log10(monoFFTAverage[i]*10))+1)+(Math.ceil(height/2*Math.log10(monoFFTDeviation[i]*10))+1)
    //           rect(barCoordX,barCoordY,barWidth,barHeight)
    //           fill(255,221,230)
    //           barWidth = Math.ceil((width)/sideFFTDeviation.length)
    //           barHeight= 1           
    //           barCoordX = Math.ceil(i*barWidth)
    //           barCoordY = height-(Math.ceil(height/2*Math.log10(sideFFTAverage[i]*10))+1)+(Math.ceil(height/2*Math.log10(sideFFTDeviation[i]*10))+1)
    //           rect(barCoordX,barCoordY,barWidth,barHeight)
    //         }
    //       }
    //    // console.log(max)
        
    // }
    function windowResized() {
        //centerCanvas();
    }
  


const { app, BrowserWindow } = require('electron')
require('electron-reload').apply(__dirname)
function createWindow () {
  // Create the browser window.
  let win = new BrowserWindow({
    //width: 1024,
    width: 289,
    height: 77,
    webPreferences: {
      nodeIntegration: true
    },
    resizable:false,
  })

  // and load the index.html of the app.
  win.loadFile('index.html')
}

app.on('ready', createWindow)